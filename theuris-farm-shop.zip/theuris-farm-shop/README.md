# Theuri's Farm — Ordering Website

A single-file static website where customers order milk, eggs, and chicken,
then send the order to you by **email (Gmail)** or **WhatsApp/phone call**.
No backend, database, or hosting account required to get started.

## 1. Configure it (required)

Open `index.html`, find the `FARM_CONFIG` block near the top (~line 15), and edit:

```js
window.FARM_CONFIG = {
  orderEmail: "YOUR_FARM_EMAIL@gmail.com",   // where email orders go
  phoneDisplay: "+254 7XX XXX XXX",          // shown to customers
  phoneWhatsApp: "2547XXXXXXXX",             // digits only: country code + number, no + or leading 0
  prices: { milk: 70, eggs: 15, chicken: 800 }, // KES per litre / egg / bird
  location: "Theuri's Farm, Kiambu County, Kenya"
};
```

That's it — every price, email link, WhatsApp link, and phone link on the page
pulls from these five values.

## 2. How ordering works

- Customer sets quantities for milk / eggs / chicken — the order summary and
  total update live.
- **"Email this order"** opens their own email app (Gmail, Outlook, etc.) with
  your address, a subject line, and the full order pre-filled in the body —
  they just hit send.
- **"Order on WhatsApp"** opens WhatsApp Web/app with the order pre-filled as a
  message to your WhatsApp number.
- **"Call us instead"** dials your phone number directly on mobile.

No server processes anything — the browser builds the `mailto:` and
`wa.me` links directly from what the customer typed, so there's nothing to
host or maintain beyond the one HTML file.

## 3. Publish it

Any of these work, in order of ease:
- **GitHub Pages**: push this file to a repo, enable Pages — free, ~2 minutes.
- **Netlify / Vercel drop**: drag the folder onto their web dashboard.
- **Your own hosting**: it's one static file — upload it anywhere.

## 4. If you outgrow mailto/WhatsApp later

This works well for a farm taking a modest number of daily orders. If you
later want orders saved to a real order log, sent automatically without
opening the customer's email app, or tracked with statuses — that needs a
small backend (e.g. a form service like Formspree, or a proper database like
the one in your TFMRS system) and is a natural next step, not a rebuild.
